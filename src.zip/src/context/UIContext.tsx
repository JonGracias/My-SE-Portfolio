"use client";
import MessageShell from "@/components/MessageShell";

import React, {
  createContext,
  useContext,
  useState,
  ReactNode
} from "react";

interface RepoMessage {
  repoName: string;
  content: ReactNode;
}

interface UIContextType {
  // Hovered repository (for popup or highlight behavior)
  hoveredRepo: any | null;
  setHoveredRepo: (repo: any | null) => void;

  // Message content and position (repo popover, star popup, language popup, etc)
  message: RepoMessage | null;
  setMessage: (repoName: string, content: ReactNode) => void;

  // Scrolling flag (to hide messages on scroll)
  scrolling: boolean;
  setScrolling: (state: boolean) => void;

  // Clearing Popup
  clearMessage: () => void;
  clearHoveredRepo: () => void;
}

const UIContext = createContext<UIContextType | undefined>(undefined);

export function UIProvider({ children }: { children: ReactNode }) {
  const [hoveredRepo, _setHoveredRepo] = useState<any | null>(null);

  const [message, _setMessage] = useState<RepoMessage | null>(null);

  const [scrolling, setScrolling] = useState(false);

  const clear = true

 

  function setMessage(repoName: string, message: ReactNode) {
    _setMessage({
      repoName,
      content: (
        <MessageShell onClose={clearMessage}>
          {message}
        </MessageShell>
      ),
    });
  }
  function setHoveredRepo(repo: any) {
    _setHoveredRepo(repo);
  }

  
  function clearMessage() {
    if (clear) {
      _setMessage(null);
    }
  }
  function clearHoveredRepo() {
    if (clear) {
      _setHoveredRepo(null);
    }
  }
  return (
    <UIContext.Provider
      value={{
        hoveredRepo,
        setHoveredRepo,

        message,
        setMessage,

        scrolling,
        setScrolling,

        clearMessage,
        clearHoveredRepo,
      }}
    >
      {children}
    </UIContext.Provider>
  );
}

export function useUIContext() {
  const ctx = useContext(UIContext);
  if (!ctx) throw new Error("useUIContext must be used inside UIProvider");
  return ctx;
}
